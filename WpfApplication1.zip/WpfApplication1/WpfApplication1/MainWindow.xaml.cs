﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            lblNumber.Content += "1";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            lblNumber.Content += "2";
        }

        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            lblNumber.Content += "3";
        }

        private void btn4_Click(object sender, RoutedEventArgs e)
        {
            lblNumber.Content += "4";
        }

        private void btn5_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn6_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn7_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn8_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn9_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btn0_Click(object sender, RoutedEventArgs e)
        {
            ServiceReference1.WeatherSoap weatherService = new ServiceReference1.WeatherSoapClient();
            lblNumber.Content = weatherService.GetCityForecastByZIP("33919");
        }
    }
}
